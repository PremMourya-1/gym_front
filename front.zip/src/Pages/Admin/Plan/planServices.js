import toast from "react-hot-toast";
import adminApi from "../../../Service/api";

async function getPlanData(setPlanList) {
  try {
    const res = await adminApi.plan();
    setPlanList(res.data.data);
  } catch (e) {
    console.log(e);
  }
}
async function createAndPlan(data, id, setDrawer, setPlanList, setIsLoading) {
  try {
    setIsLoading(true);
    let res;
    res = id
      ? await adminApi.editPlan({ id, data })
      : await adminApi.createPlan(data);
    setIsLoading(false);

    if (res.data.action) {
      setDrawer(false);
      toast.success(res.data.message);

      if (id) {
        setPlanList((prev) => {
          return prev && prev.map((x) => (x.id === id ? res.data.data : x));
        });
      } else {
        setPlanList((prev) => {
          return prev ? [res.data.data, ...prev] : [res.data.data];
        });
      }
    } else toast.error(res.data.message);
  } catch (e) {
    console.log(e);
  }
}
async function deletePlan(id, setIsLoading, setPlanList, setModal) {
  try {
    setIsLoading(true);
    const res = await adminApi.deletePlan({ id });
    setIsLoading(false);
    if (res.data.action) {
      setModal(false);
      toast.success(res.data.message);
      setPlanList((prev) => {
        return prev && prev.filter((x) => x.id !== id);
      });
    } else toast.error(res.data.message);
  } catch (e) {
    console.log(e);
  }
}
export { getPlanData, deletePlan };

export default createAndPlan;
